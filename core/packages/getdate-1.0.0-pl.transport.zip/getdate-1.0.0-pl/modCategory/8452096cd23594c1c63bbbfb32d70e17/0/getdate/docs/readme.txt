--------------------
Extra: getDate
--------------------
Version: 1.0.0-pl
Released: November 22, 2013
Since: November 22, 2013
Author: David Pede <dev@tasianmedia.com> <https://twitter.com/davepede>
Copyright: (C) 2013 David Pede. All rights reserved. <dev@tasianmedia.com>

A simple timestamp retrieval Snippet for MODX Revolution.

Official Documentation:
http://rtfm.modx.com/display/ADDON/getDate

GitHub Repository:
http://github.com/tasianmedia/getDate

Bugs & Feature Requests:
http://github.com/tasianmedia/getDate/issues

License:
Released under the GNU General Public License; either version 2 of the License, or (at your option) any later version.
http://www.gnu.org/licenses/gpl.html